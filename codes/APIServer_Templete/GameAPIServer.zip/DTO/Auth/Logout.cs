﻿namespace APIServer.DTO.Auth;

public class LogoutResponse : ErrorCodeDTO
{
}
