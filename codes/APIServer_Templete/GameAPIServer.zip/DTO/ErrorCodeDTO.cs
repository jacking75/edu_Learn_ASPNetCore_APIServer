﻿public class ErrorCodeDTO
{
    public ErrorCode Result { get; set; } = ErrorCode.None;
}
