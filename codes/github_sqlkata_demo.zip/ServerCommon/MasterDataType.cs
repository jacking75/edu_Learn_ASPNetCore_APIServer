﻿using System;

namespace ServerCommon;

public enum LookItemType : UInt32
{
    Eye = 8,
    HairStyle = 9,
    Cloak = 10,
    Dress = 11,
    Pants = 12,
    Mustache = 13
}

public enum WeaponItemType : UInt32
{
    Sword = 1,
    Helmet = 2,
    Armor = 3
}

//캐릭터 생성에 대한 기획데이터 
public enum CreateCharacterData
{
    BasicMode = 1,
    MiddleMode = 2,
    Hard = 3
}