﻿using System;

namespace ServerCommon.Redis;

public class ExpiryTimes
{
    public const Int32 UserCurStateHour = 6;

    public const Int32 AuthTokenDay = 1;

    public const Int32 AuthTokenNxSec = 10;

    public const Int32 EnterFieldTokenHour = 1;
}