﻿using System;

namespace ServerCommon.Redis;

public class UserInfo
{
    public Int64 AccountId { get; set; }
    public string AuthToken { get; set; }
    
    public Int32 Status { get; set; }

    // 필드 입장(게임서버 접속)과 관련된 정보
    public string NickName { get; set; }
    public Int64 CharacterId { get; set; }
    public string AuthTokenForField { get; set; }
    public Int16 WorldId { get; set; }
    public Int16 FieldChannelNum { get; set; }
}