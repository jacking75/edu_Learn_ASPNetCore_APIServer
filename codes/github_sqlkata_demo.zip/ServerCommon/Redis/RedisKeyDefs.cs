﻿using System;

namespace ServerCommon.Redis;

public class RedisKeyDefs
{
    public static String LoginKey(Int64 accountId)
    {
        return "login_" + accountId;
    }

    public static String LockKey(Int64 accountId)
    {
        return "lock_" + accountId;
    }

    public static String EnterFieldKey(Int64 characterId)
    {
        return "enter_field_" + characterId;
    }
}