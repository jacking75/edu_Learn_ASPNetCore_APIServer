﻿using MessagePack;
using System;
using System.Collections.Generic;
using System.Text;

namespace ServerCommon.Redis
{
    public struct MsgPackDataHeaderInfo
    {
        const int HeaderStartPos = 3;
        public const int HeadSize = 5;

        public UInt16 _taskId;

        public static void WritePacketID(byte[] data, UInt16 taskId)
        {
            FastBinaryWrite.UInt16(data, HeaderStartPos, taskId);
        }

        public void Read(byte[] taskData)
        {
            var pos = HeaderStartPos;
            _taskId = FastBinaryRead.UInt16(taskData, pos);

        }

    }


    [MessagePackObject]
    public class MsgPackTaskHead
    {
        [Key(0)]
        public Byte[] _head = new Byte[MsgPackDataHeaderInfo.HeadSize];

        [Key(1)]
        public string _netSessionID;
    }

    public class ReqLoginTask : MsgPackTaskHead
    {
        [Key(2)]
        public string _userID;

        [Key(3)]
        public string _authToken;
    }
}
