﻿using System;

namespace ServerCommon.FieldObjects;

public class Npc : FieldObject
{
    public Int32 Level { get; set; }
    public bool Move { get; set; } = false;
    public Int32 Hp { get; set; }
    public Int32 Mp { get; set; }
}