﻿using System;
using GameServer.Field.PKHandler;

namespace ServerCommon.FieldObjects;

public class FieldObject
{
    public UInt32 Uid { get; set; }
    public FieldObjectType FieldObjectType { get; set; }
    public Int32 LocationX { get; set; }
    public Int32 LocationY { get; set; }
}