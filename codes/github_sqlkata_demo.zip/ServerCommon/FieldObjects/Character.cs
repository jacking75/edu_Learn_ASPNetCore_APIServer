﻿using System;
using System.Collections.Generic;
using MessagePack;

namespace ServerCommon.FieldObjects;

public class Character : FieldObject
{
    private readonly List<CharacterItem> _characterItmeLst = new();

    private readonly CharacterLook _characterLook = new();

    public List<Int32> skillCd = new();

    public Character()
    {
    }

    public Character(PkCharacter pkCharacter, PkCharacterLook pkCharacterLook, UInt16 gatewayId)
    {
        CharacterId = pkCharacter.CharacterId;
        AccountId = pkCharacter.AccountId;
        Nickname = pkCharacter.Nickname;
        Exp = pkCharacter.Exp;
        Level = pkCharacter.Level;
        Hp = pkCharacter.Hp;
        Mp = pkCharacter.Mp;
        LocationX = pkCharacter.LocationX;
        LocationY = pkCharacter.LocationY;
        Gold = pkCharacter.Gold;

        _characterLook.CharacterId = pkCharacter.CharacterId;
        _characterLook.Eye = pkCharacterLook.Eye;
        _characterLook.HairStyle = pkCharacterLook.HairStyle;
        _characterLook.Mustache = pkCharacterLook.Mustache;
        _characterLook.Cloak = pkCharacterLook.Cloak;
        _characterLook.Pants = pkCharacterLook.Pants;
        _characterLook.Dress = pkCharacterLook.Dress;
        _characterLook.Helmet = pkCharacterLook.Helmet;
        _characterLook.Armor = pkCharacterLook.Armor;
        _characterLook.Weapon = pkCharacterLook.Weapon;

        CurruntGatewayId = gatewayId;
    }

    public Int32 AnimationCd { get; set; }
    public DateTime SkillHoldingTime { get; set; } = DateTime.Now;
    public bool Move { get; set; } = false;
    public Int64 CharacterId { get; set; }
    public Int64 AccountId { get; set; }
    public String Nickname { get; set; }
    public Int32 Exp { get; set; }
    public Int32 Level { get; set; }
    public Int32 Hp { get; set; }
    public Int32 Mp { get; set; }
    public Int32 Power { get; set; }    
    public Int64 Gold { get; set; }

    public bool IsDelete { get; set; }

    public UInt16 CurruntGatewayId { get; set; }

    public void InitItem(List<PkCharacterItem> pkCharacterItem)
    {
        foreach (var pkItem in pkCharacterItem)
        {
            var item = new CharacterItem(pkItem);
            _characterItmeLst.Add(item);
        }
    }

    public List<CharacterItem> GetItemList()
    {
        return _characterItmeLst;
    }
}

public class CharacterLook
{
    public Int64 CharacterId { get; set; }
    public Int32 Eye { get; set; }
    public Int32 HairStyle { get; set; }
    public Int32 Mustache { get; set; }
    public Int32 Cloak { get; set; }
    public Int32 Pants { get; set; }
    public Int32 Dress { get; set; }
    public Int32 Helmet { get; set; }
    public Int32 Armor { get; set; }

    public Int32 Weapon { get; set; }

    public bool IsDelete { get; set; } = false;
}

public class CharacterItem
{
    public CharacterItem()
    {
    }

    public CharacterItem(PkCharacterItem pkCharacterItem)
    {
        CharacterItemId = pkCharacterItem.CharacterItemId;
        Code = pkCharacterItem.Code;
        Status = pkCharacterItem.Status;
    }

    public Int64 CharacterItemId { get; set; }
    public Int64 CharacterId { get; set; }
    public Int32 Code { get; set; }

    public Int32 Status { get; set; }
}

[MessagePackObject]
public class PkCharacter
{
    // Character Data
    [Key(1)] public Int64 CharacterId { get; set; }
    [Key(2)] public Int64 AccountId { get; set; }
    [Key(3)] public String Nickname { get; set; }
    [Key(4)] public Int32 Exp { get; set; }
    [Key(5)] public Int32 Level { get; set; }
    [Key(6)] public Int32 Hp { get; set; }
    [Key(7)] public Int32 Mp { get; set; }
    [Key(8)] public Int32 LocationX { get; set; }
    [Key(9)] public Int32 LocationY { get; set; }
    [Key(10)] public Int64 Gold { get; set; }
    [Key(11)] public Int16 ChannelNum { get; set; }
}

[MessagePackObject]
public class PkCharacterLook
{
    // Character Look Data
    [Key(1)] public Int32 Eye { get; set; }
    [Key(2)] public Int32 HairStyle { get; set; }
    [Key(3)] public Int32 Mustache { get; set; }
    [Key(4)] public Int32 Cloak { get; set; }
    [Key(5)] public Int32 Pants { get; set; }
    [Key(6)] public Int32 Dress { get; set; }
    [Key(7)] public Int32 Helmet { get; set; }
    [Key(8)] public Int32 Armor { get; set; }
    [Key(9)] public Int32 Weapon { get; set; }
}

[MessagePackObject]
public class PkCharacterItem
{
    // Character Item Data
    [Key(1)] public Int64 CharacterItemId { get; set; }
    [Key(2)] public Int32 Code { get; set; }
    [Key(3)] public Int32 Status { get; set; }
}



public enum CharacterState
{
    Sleep,
    Active
}