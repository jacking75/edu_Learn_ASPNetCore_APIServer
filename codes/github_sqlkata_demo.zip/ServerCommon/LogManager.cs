﻿using System;
using Microsoft.Extensions.Logging;

namespace ServerCommon;

public static class LogManager
{
    private static ILoggerFactory s_loggerFactory;

    public static ILogger Logger { get; private set; }

    public static void SetLoggerFactory(ILoggerFactory loggerFactory, String categoryName)
    {
        s_loggerFactory = loggerFactory;
        Logger = loggerFactory.CreateLogger(categoryName);
    }

    public static ILogger<T> GetLogger<T>() where T : class
    {
        return s_loggerFactory.CreateLogger<T>();
    }

    public static ILogger GetLogger(String categoryName)
    {
        return s_loggerFactory.CreateLogger(categoryName);
    }
}