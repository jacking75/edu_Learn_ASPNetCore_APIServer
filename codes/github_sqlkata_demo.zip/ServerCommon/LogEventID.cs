﻿using System;

namespace ServerCommon;

public class LogEventID
{
    // API 서버 1000 ~
    public const Int32 ApiCreateAccount = 1001;
    public const Int32 ApiLogin = 1002;
    public const Int32 ApiCreateCharacter = 1003;
    public const Int32 ApiDeleteCharacter = 1004;


    // Gateway 서버 2000 ~
    public const Int32 GatewayLogin = 2001;

    // 로비 서버
    // 게임 서버
    // 매치 서버
    // 센터 서버
    // DB 서버 7001
    public const Int32 DbProgramInit = 7001;
    public const Int32 DbProgramEnd = 7002;
    public const Int32 DbLogicErrorProcessWorkerQueue = 7003;
}