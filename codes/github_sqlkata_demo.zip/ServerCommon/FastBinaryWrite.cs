﻿using System;

namespace ServerCommon;

public class FastBinaryWrite
{
    public static void Boolean(Byte[] bytes, Int32 offset, bool value)
    {
        bytes[offset] = (Byte)(value ? 1 : 0);
    }

    public static void BoolTrueUnsafe(Byte[] bytes, Int32 offset)
    {
        bytes[offset] = 1;
    }

    public static void BoolFalseUnsafe(Byte[] bytes, Int32 offset)
    {
        bytes[offset] = 0;
    }

    public static void Byte(Byte[] bytes, Int32 offset, Byte value)
    {
        bytes[offset] = value;
    }

    public static Int32 Bytes(Byte[] bytes, Int32 offset, Byte[] value)
    {
        Buffer.BlockCopy(value, 0, bytes, offset, value.Length);
        return value.Length;
    }

    public static Int32 SByte(Byte[] bytes, Int32 offset, SByte value)
    {
        bytes[offset] = (Byte)value;
        return 1;
    }

    public static unsafe Int32 Single(Byte[] bytes, Int32 offset, Single value)
    {
        if (offset % 4 == 0)
        {
            fixed (Byte* ptr = bytes)
            {
                *(Single*)(ptr + offset) = value;
            }
        }
        else
        {
            var num = *(UInt32*)(&value);
            bytes[offset] = (Byte)num;
            bytes[offset + 1] = (Byte)(num >> 8);
            bytes[offset + 2] = (Byte)(num >> 16);
            bytes[offset + 3] = (Byte)(num >> 24);
        }

        return 4;
    }

    public static unsafe Int32 Double(Byte[] bytes, Int32 offset, Double value)
    {
        if (offset % 8 == 0)
        {
            fixed (Byte* ptr = bytes)
            {
                *(Double*)(ptr + offset) = value;
            }
        }
        else
        {
            var num = (UInt64)(*(Int64*)(&value));
            bytes[offset] = (Byte)num;
            bytes[offset + 1] = (Byte)(num >> 8);
            bytes[offset + 2] = (Byte)(num >> 16);
            bytes[offset + 3] = (Byte)(num >> 24);
            bytes[offset + 4] = (Byte)(num >> 32);
            bytes[offset + 5] = (Byte)(num >> 40);
            bytes[offset + 6] = (Byte)(num >> 48);
            bytes[offset + 7] = (Byte)(num >> 56);
        }

        return 8;
    }

    public static unsafe Int32 Int16(Byte[] bytes, Int32 offset, Int16 value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(Int16*)(ptr + offset) = value;
        }

        return 2;
    }

    public static unsafe Int32 Int32(Byte[] bytes, Int32 offset, Int32 value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(Int32*)(ptr + offset) = value;
        }

        return 4;
    }

    public static unsafe void Int32Unsafe(Byte[] bytes, Int32 offset, Int32 value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(Int32*)(ptr + offset) = value;
        }
    }

    public static unsafe Int32 Int64(Byte[] bytes, Int32 offset, Int64 value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(Int64*)(ptr + offset) = value;
        }

        return 8;
    }

    public static unsafe Int32 UInt16(Byte[] bytes, Int32 offset, UInt16 value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(UInt16*)(ptr + offset) = value;
        }

        return 2;
    }

    public static unsafe Int32 UInt32(Byte[] bytes, Int32 offset, UInt32 value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(UInt32*)(ptr + offset) = value;
        }

        return 4;
    }

    public static unsafe Int32 UInt64(Byte[] bytes, Int32 offset, UInt64 value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(UInt64*)(ptr + offset) = value;
        }

        return 8;
    }

    public static Int32 Char(Byte[] bytes, Int32 offset, Char value)
    {
        return UInt16(bytes, offset, value);
    }

    public static Int32 String(Byte[] bytes, Int32 offset, String value)
    {
        return StringEncoding.UTF8.GetBytes(value, 0, value.Length, bytes, offset);
    }

    public static unsafe Int32 Decimal(Byte[] bytes, Int32 offset, Decimal value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(Decimal*)(ptr + offset) = value;
        }

        return 16;
    }

    public static unsafe Int32 Guid(Byte[] bytes, Int32 offset, Guid value)
    {
        fixed (Byte* ptr = bytes)
        {
            *(Guid*)(ptr + offset) = value;
        }

        return 16;
    }

    #region Timestamp/Duration

    public static unsafe Int32 TimeSpan(ref Byte[] bytes, Int32 offset, TimeSpan timeSpan)
    {
        checked
        {
            var ticks = timeSpan.Ticks;
            var seconds = ticks / System.TimeSpan.TicksPerSecond;
            var nanos = (Int32)(ticks % System.TimeSpan.TicksPerSecond) * Duration.NanosecondsPerTick;

            fixed (Byte* ptr = bytes)
            {
                *(Int64*)(ptr + offset) = seconds;
                *(Int32*)(ptr + offset + 8) = nanos;
            }

            return 12;
        }
    }

    public static unsafe Int32 DateTime(ref Byte[] bytes, Int32 offset, DateTime dateTime)
    {
        dateTime = dateTime.ToUniversalTime();

        // Do the arithmetic using DateTime.Ticks, which is always non-negative, making things simpler.
        var secondsSinceBclEpoch = dateTime.Ticks / System.TimeSpan.TicksPerSecond;
        var nanoseconds = (Int32)(dateTime.Ticks % System.TimeSpan.TicksPerSecond) * Duration.NanosecondsPerTick;

        fixed (Byte* ptr = bytes)
        {
            *(Int64*)(ptr + offset) = secondsSinceBclEpoch - Timestamp.BclSecondsAtUnixEpoch;
            *(Int32*)(ptr + offset + 8) = nanoseconds;
        }

        return 12;
    }

    internal static class Timestamp
    {
        internal const Int64 BclSecondsAtUnixEpoch = 62135596800;
        internal const Int64 UnixSecondsAtBclMaxValue = 253402300799;
        internal const Int64 UnixSecondsAtBclMinValue = -BclSecondsAtUnixEpoch;
        internal const Int32 MaxNanos = Duration.NanosecondsPerSecond - 1;
        internal static readonly DateTime UnixEpoch = new(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        internal static bool IsNormalized(Int64 seconds, Int32 nanoseconds)
        {
            return nanoseconds >= 0 &&
                   nanoseconds <= MaxNanos &&
                   seconds >= UnixSecondsAtBclMinValue &&
                   seconds <= UnixSecondsAtBclMaxValue;
        }
    }

    internal static class Duration
    {
        public const Int32 NanosecondsPerSecond = 1000000000;
        public const Int32 NanosecondsPerTick = 100;
        public const Int64 MaxSeconds = 315576000000L;
        public const Int64 MinSeconds = -315576000000L;
        internal const Int32 MaxNanoseconds = NanosecondsPerSecond - 1;
        internal const Int32 MinNanoseconds = -NanosecondsPerSecond + 1;

        internal static bool IsNormalized(Int64 seconds, Int32 nanoseconds)
        {
            // Simple boundaries
            if (seconds < MinSeconds || seconds > MaxSeconds ||
                nanoseconds < MinNanoseconds || nanoseconds > MaxNanoseconds)
            {
                return false;
            }

            // We only have a problem is one is strictly negative and the other is
            // strictly positive.
            return Math.Sign(seconds) * Math.Sign(nanoseconds) != -1;
        }
    }

    #endregion
}