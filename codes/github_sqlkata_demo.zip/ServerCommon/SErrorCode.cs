﻿using System;

namespace ServerCommon;

// 20000 ~ 
public enum SErrorCode : UInt16
{
    None = 0,

    // Common
    UnhandledException = 20001,

    // Gateway 전용  20201 ~ 20400
    GwFailInitSetup = 20201,
    GwFailSuperSocketStart = 20202,

    GwFailEnterFieldAlreadyLogin = 20222,
    GwFailEnterFieldIsNotLogin = 20223,
    GwFailEnterFieldAlreadyEnterField = 20224,
    GwFailLoadItemIsNotLogin = 20225,
    GwFailLoadItemIsNotEnterField = 20226,

    

    // Game 21001 ~ 21500 
    LoadCharacterInfoFail = 21001,
    LoadItemFail = 21001,
    OperateSkillFail = 21002,
    ExistCharacter = 21003,
    NotExistCharacter = 21004,
    ExceedMaxUserCount = 21005,
    AlreadyInitItem = 21006,

    // DB  21501 ~ 21800
    MySqlFailException = 21501,
    RedisFailException = 21502,
    DbsInvalidAccount = 21503,
    DbsInvalidAuthToken = 21504,
    DbsDuplicatedLogin = 21505,
    DbsNotExistCharacter = 21507,
    DbsNotExistCharacterItem = 21508,
    DbsInvalidCharacter = 21509
}

public class SErrorCodeException : Exception
{
    public SErrorCode errorCode;

    public SErrorCodeException(SErrorCode sErrorCode)
    {
        errorCode = sErrorCode;
    }
}