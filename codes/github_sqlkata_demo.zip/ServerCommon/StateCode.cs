﻿using System;

namespace ServerCommon;

public enum ItemStatus : UInt16
{
    //아이템 장착 중인 상태값 추가. 
    ItemEquip = 10,

    //Item 상태코드 
    ItemDelete = 100,
    ItemDestruct = 101
}

public enum CharacterStatus : UInt16
{
    //계정 상태코드  1 ~ 100
    EnterField = 1,
    None
}