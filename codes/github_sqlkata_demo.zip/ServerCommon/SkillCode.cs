﻿using System;

namespace ServerCommon;

public enum SkillType : UInt16
{
    Passive = 1,
    Toggle = 2,
    Short = 3,
    LoongFire = 4,
    BuffBoom = 5,
    Global = 6,
    Life = 7
}

public enum UseSkillResult : UInt16
{
    Successful = 1,
    CoolTimeFail = 2,
    ResourceFail = 3,
    CharacterNull = 5,
    LevelFail = 6,
    TotalValidFail = 7,
    DistanceFail = 8
}

public enum SkillResourceCheck : UInt16
{
    Successful = 1,
    FailMpResource = 2,
    FailHpResource = 3
}

public enum SkillCd
{
    PowerAttack = 1, // 건곤대나이 
    TogetherDie = 2, // 동귀어진
    MultiAttack = 3, // 섬격 
    Coincide = 4, // 신검합일 네이밍 수정 예정 ..
    GodBlessYou = 5, // 신의 축복 
    CallOfWill = 6 // 의지의 외침 
}