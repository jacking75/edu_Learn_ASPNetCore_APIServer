﻿namespace GameServer.Field.PKHandler;

public enum FieldObjectType
{
    //아군인지 적군인지 몬스터인지 npc인지 

    Monster = 1,
    Npc = 2,
    Enemy = 3,
    Friendly = 4,
    Player = 5
}