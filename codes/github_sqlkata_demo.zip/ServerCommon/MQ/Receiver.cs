﻿using System;
using NATS.Client;

namespace ServerCommon.MQ;

public class Receiver
{
    private IConnection _connection;
    private IAsyncSubscription _subscription;

    public Action<Byte[]> ReceivedMqData;

    // qGroup가 공백이나 null이 아니면 Queue로 동작한다
    public void Init(String serverAddress, String subject, String qGroup)
    {
        var opts = ConnectionFactory.GetDefaultOptions();
        opts.Url = serverAddress;

        _connection = new ConnectionFactory().CreateConnection(opts);

        if (string.IsNullOrEmpty(qGroup))
        {
            _subscription = _connection.SubscribeAsync(subject, ReceiveHandler);
        }
        else
        {
            _subscription = _connection.SubscribeAsync(subject, qGroup);
            _subscription.MessageHandler += ReceiveHandler;
            _subscription.Start();
        }
    }

    private void ReceiveHandler(Object m, MsgHandlerEventArgs ea)
    {
        ReceivedMqData(ea.Message.Data);
    }

    public void Destroy()
    {
        _subscription?.Dispose();
        _connection?.Dispose();
    }
}