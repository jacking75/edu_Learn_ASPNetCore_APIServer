﻿using System;
using System.Collections.Generic;
using MessagePack;
using ServerCommon.FieldObjects;

namespace ServerCommon.MQ;

[MessagePackObject]
public class PkGsLoadCharacterInfoRes : PacketHead
{
    [Key(1)] public Int16 Result;
    [Key(2)] public PkCharacter PkCharacterInfo;
    [Key(3)] public PkCharacterLook PkCharacterLookInfo;
    [Key(4)] public UInt16 GatewayId;
}

[MessagePackObject]
public class PkGsLoadItemReq : PacketHead
{
    [Key(1)] public Int64 CharacterId;
}

[MessagePackObject]
public class PkGsLoadItemInfoRes : PacketHead
{
    [Key(1)] public Int16 Result;
    [Key(2)] public Int64 CharacterId;
    [Key(3)] public List<PkCharacterItem> PkCharacterItemInfoList;
    [Key(4)] public UInt16 GatewayId;
}

[MessagePackObject]
public class PkGsLoadCharacterSkillRes : PacketHead
{
    [Key(1)] public Int16 Result;
    [Key(2)] public IEnumerable<MasterSkillData> PkDbsCharacterSkill;
}

[MessagePackObject]
public class PkGsExcuteCharacterSkillReq : PacketHead
{
    [Key(1)] public Int16 SkillCd;
    [Key(2)] public Int64 CharacterId;
    [Key(3)] public List<Int64> TargetId;
}

[MessagePackObject]
public class PkGsExcuteCharacterSkillRes : PacketHead
{
    [Key(1)] public Int16 Result;
}