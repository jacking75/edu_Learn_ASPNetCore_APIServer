﻿using System;
using NATS.Client;

namespace ServerCommon.MQ;

public class Sender
{
    private IConnection _connection;

    public void Init(String serverAddress)
    {
        var opts = ConnectionFactory.GetDefaultOptions();
        opts.Url = serverAddress;

        _connection = new ConnectionFactory().CreateConnection(opts);
    }

    public void Destroy()
    {
        _connection?.Dispose();
    }

    public void Send(String subject, Byte[] payload, Int32 offset, Int32 count)
    {
        _connection.Publish(subject, payload, offset, count);
    }

    public void Send(String subject, Byte[] payload)
    {
        try
        {
            _connection.Publish(subject, payload);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }
}