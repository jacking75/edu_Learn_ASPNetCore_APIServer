﻿using System;
using System.Collections.Generic;
using MessagePack;

namespace ServerCommon.MQ;


[MessagePackObject]
public class PkDBSMasterDataReq : PacketHead
{
}

public class MasterSkillData
{
    public Int32 SkillCd { get; set; }
    public String Name { get; set; }
    public Int32 CastingTime { get; set; }
    public Int32 CoolTime { get; set; }
    public Int32 LvLimit { get; set; }
    public Int32 DecHp { get; set; }
    public Int32 DecMp { get; set; }
    public UInt16 SkillType { get; set; }
    public Int32 AnimationCd { get; set; }
    public Int32 MinDistance { get; set; }
    public Int32 MaxDistance { get; set; }
    public Int32 SkillLv { get; set; }
    public Int32 EffectKeepUpTime { get; set; }
    public Int32 Scope { get; set; }
    public Int32 IncHp { get; set; }
    public Int32 IncMp { get; set; }
    public Int32 IncPower { get; set; }
    public Int32 Damage { get; set; }
}

[MessagePackObject] 
public class PkDBSMasterDataSkillNtf : PacketHead
{
    [Key(1)] public List<MasterSkillData> SkillDatas;
}


[MessagePackObject]
public class PkDBSMasterDataRes : PacketHead
{
}





[MessagePackObject]
public class PkDbsGwsLogin : PacketHead
{
    [Key(1)] public Int16 Result;
    [Key(2)] public Int64 AccountId;    
    [Key(3)] public Int64 CharacterId;
    [Key(4)] public Int16 ChannelId;
    [Key(5)] public Int16 WorldId;
    [Key(6)] public string NickName;
}


[MessagePackObject]
public class PkDbsCharacterSkill : PacketHead
{
    [Key(1)] public Int32 SkillCd { get; set; }
    [Key(2)] public String Name { get; set; }
    [Key(3)] public String CastingTime { get; set; }
    [Key(4)] public Int32 CoolTime { get; set; }
    [Key(5)] public Int32 LvLimit { get; set; }
    [Key(6)] public Int32 DecHp { get; set; }
    [Key(7)] public Int32 DecMp { get; set; }
    [Key(8)] public Int32 SkillType { get; set; }
    [Key(9)] public Int32 ParentSkillCd { get; set; }
    [Key(10)] public Int32 ChildSkillCd { get; set; }
    [Key(11)] public Int32 AnimationCd { get; set; }
    [Key(12)] public Int32 MinDistance { get; set; }
    [Key(13)] public Int32 MaxDistance { get; set; }
    [Key(14)] public Int32 SkillLv { get; set; }
    [Key(15)] public Int32 EffectKeepUpTime { get; set; }
    [Key(16)] public Int32 Scope { get; set; }
    [Key(17)] public Int32 Error { get; set; }
}

[MessagePackObject]
public class PkDbsGatewayLogin : PacketHead
{
    [Key(1)] public Int64 AccountId;
    [Key(2)] public String EnterFieldToken;
}

public class PkGsEnterField : PacketHead
{
    [Key(1)] public Int64 AccountId;
    [Key(2)] public UInt64 UniqueId;
    [Key(3)] public String EnterFieldToken;
}

[MessagePackObject]
public class PkDbsUserDisconnected : PacketHead
{
    [Key(1)] public Int64 AccountId;
}

[MessagePackObject]
public class PkDbsLoadCharacterInfoReq : PacketHead
{
    [Key(1)] public Int64 CharacterId;
    [Key(2)] public Int16 ChannelId;
    [Key(3)] public UInt16 GatewayId;
}

//TODO 잘못된 정의인 것 같음
[MessagePackObject]
public class PkDbsLoadItemInfoReq : PacketHead
{
    [Key(1)] public Int64 CharacterId;
    [Key(2)] public Int16 ChannelId;
    [Key(3)] public UInt16 GatewayId;
}

