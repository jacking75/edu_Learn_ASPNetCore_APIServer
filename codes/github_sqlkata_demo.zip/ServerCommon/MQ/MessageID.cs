﻿using System;

namespace ServerCommon.MQ;

public enum MessageId : UInt16
{
    // Game Server  1001 ~ 2000
    GsLoadMasterDataReq = 1003,

    GsEnterFieldReq = 1011,
    GsLoadCharacterInfoRes = 1012,

    GsLoadItemReq = 1014,
    GsLoadItemRes = 1015,
    
    UseSkill = 1502, 



    // DBServer 2001 ~ 3000    
    DbsLoadMasterDataSkillNtf = 2006,
    DbsLoadMasterDataRes = 2040,

    DbsCheckLogin = 2101,
    DbsUserDisconnected = 2103,
    DbsLoadCharacterInfoReq = 2111,
    DbsLoadItemInfoReq = 2112,



    // Gateway Server 3001 ~ 4000
    GwsLogin = 3101,
    GwsEnterFieldRes = 3102,

    GwsLoadItemRes = 3105
}