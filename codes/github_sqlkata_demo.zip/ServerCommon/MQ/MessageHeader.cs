﻿using System;
using MessagePack;

namespace ServerCommon.MQ;

public struct PacketHeaderInfo
{
    const Int32 RealStartPos = 3;    
    const Int32 MultiUserDataOffsetPos = RealStartPos + 2 + 1 + 2 + 2 + 8;
    const Int32 ChannelIdOffsetPos = RealStartPos + 2 + 1 + 2;

    public const Int32 HeadSize = MultiUserDataOffsetPos + 2;

    public UInt16 Id; // 패킷 Index
    private byte Type; // 패킷의 속성
    public UInt16 SenderIndex;// 패킷을 보내는 서버의 인덱스
    public Int16 ChannelId; //게임서버에서의 채널 Id
    public UInt64 UidInGws; //게이트웨이 서버에서의 유저 유니크 번호
    private UInt16 _multiUserDataOffset;

    public void Read(Byte[] headerData)
    {
        var pos = RealStartPos;

        Id = FastBinaryRead.UInt16(headerData, pos);
        pos += 2;

        Type = headerData[pos];
        pos += 1;

        SenderIndex = FastBinaryRead.UInt16(headerData, pos);
        pos += 2;

        ChannelId = FastBinaryRead.Int16(headerData, pos);
        pos += 2;

        UidInGws = FastBinaryRead.UInt64(headerData, pos);
        pos += 8;
          
        _multiUserDataOffset = FastBinaryRead.UInt16(headerData, pos);
    }

    public void Write(byte[] mqData, Int32 offset = 0)
    {
        var pos = offset + RealStartPos;

        FastBinaryWrite.UInt16(mqData, pos, Id);
        pos += 2;

        mqData[pos] = Type;
        pos += 1;

        FastBinaryWrite.UInt16(mqData, pos, SenderIndex);
        pos += 2;

        FastBinaryWrite.Int16(mqData, pos, ChannelId);
        pos += 2;

        FastBinaryWrite.UInt64(mqData, pos, UidInGws);
        pos += 8;

        FastBinaryWrite.UInt16(mqData, pos, _multiUserDataOffset);
    }

    public static void WriteMultiUserDataOffset(Byte[] mqData, UInt16 offset)
    {
        FastBinaryWrite.UInt16(mqData, MultiUserDataOffsetPos, offset);
    }

    public static UInt16 ReadPacketId(byte[] mqData)
    {
        return FastBinaryRead.UInt16(mqData, RealStartPos);
    }

    public static Int16 ReadChannelId(byte[] mqData)
    {
        return FastBinaryRead.Int16(mqData, ChannelIdOffsetPos);
    }
}

[MessagePackObject]
public class PacketHead
{
    [Key(0)] 
    public Byte[] Head = new Byte[PacketHeaderInfo.HeadSize];
}