﻿using System;
using System.Collections.Generic;
using MessagePack;
using ServerCommon.FieldObjects;

namespace ServerCommon.MQ;


[MessagePackObject]
public class PkGwsEnterFieldReq : PacketHead
{
    [Key(1)] public Int64 CharacterId;
    [Key(2)] public Int16 WorldId;
}


public class PkGwsEnterFieldRes : PacketHead
{
    [Key(2)] public PkCharacter PkCharacterInfo;
    [Key(3)] public PkCharacterLook PkCharacterLookInfo;
    [Key(1)] public Int16 Result;
}

public class PkGwsLoadItemRes : PacketHead
{
    [Key(3)] public Int64 CharacterId;
    [Key(2)] public List<PkCharacterItem> PkCharacterItemInfoList;
    [Key(1)] public Int16 Result;
}