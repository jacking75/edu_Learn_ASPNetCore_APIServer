﻿using System;

namespace ServerCommon.MQ;

public class SubjectManager
{
    public static String ToGameServer(UInt16 serverIndex)
    {
        return $"to.G{serverIndex}";
    }

    public static String ToGatewayServer(UInt16 gatewayServerIndex)
    {
        return $"to.GW{gatewayServerIndex}";
    }

    public static String ToDBServer()
    {
        return "to.DB";
    }
}