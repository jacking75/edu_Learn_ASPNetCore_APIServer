﻿using System;
using System.IO;
using MessagePack;

namespace ServerCommon.MQ;

public class MQPacketMaker
{
    byte[] _encodingBuffer;
    MemoryStream _encodingStream;
    PacketHeaderInfo _encoderMqHeader;

    byte[] _mqData;        
    UInt16 _myServerIndex;


    public void Init()
    {
        _encodingBuffer = new byte[8012 * 2];
        _encodingStream = new MemoryStream(_encodingBuffer);
        _encoderMqHeader = new PacketHeaderInfo();
    }

    public void SetData(byte[] data, UInt16 myServerIndex)
    {
        _mqData = data;
        _myServerIndex = myServerIndex; 
    }

    public UInt16 ServerIndex()
    {
        return _myServerIndex;
    }

    public (Int32, byte[]) Make<T>(MessageId msgId, 
                                        UInt64 uid, 
                                        T sendData)
    {
        _encodingStream.Position = 0;
        MessagePackSerializer.Serialize(_encodingStream, sendData);

        _encoderMqHeader.Id = (UInt16)msgId;
        _encoderMqHeader.SenderIndex = _myServerIndex;
        _encoderMqHeader.UidInGws = uid;
        
        _encoderMqHeader.Write(_encodingBuffer);

        var length = (Int32)_encodingStream.Position;
        return (length, _encodingBuffer);
    }
}
