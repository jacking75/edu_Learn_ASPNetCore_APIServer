﻿using System;
using System.Threading.Tasks;
using APIServer.ModelReqRes;
using APIServer.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServerCommon;
using ZLogger;

namespace APIServer.Controllers;

[ApiController]
[Route("[controller]")]
public class LoginController : ControllerBase
{
    private readonly IAccountDb _accountDb;
    private readonly ILogger<LoginController> _logger;

    public LoginController(ILogger<LoginController> logger, IAccountDb accountDb)
    {
        _logger = logger;
        _accountDb = accountDb;
    }

    [HttpPost]
    public async Task<PkLoginResponse> Post(PkLoginRequest request)
    {
        var response = new PkLoginResponse();

        // ID, PW 검증
        var (errorCode, accountId) = await _accountDb.VerifyAccount(request.Email, request.Password);
        if (errorCode != CSCommon.ErrorCode.None)
        {
            response.Result = errorCode;
            return response;
        }

                
        response.AccountId = accountId;
        
        _logger.ZLogInformationWithPayload(new EventId(LogEventID.ApiLogin),
            $"[Login] Email: {request.Email}, AccountId: {accountId}, AuthToken: none");
        return response;
    }
}
