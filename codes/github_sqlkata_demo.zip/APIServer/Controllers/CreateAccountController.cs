﻿using System;
using System.Threading.Tasks;
using APIServer.ModelReqRes;
using APIServer.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServerCommon;
using ZLogger;

namespace APIServer.Controllers;

[ApiController]
[Route("[controller]")]
public class CreateAccountController : ControllerBase
{
    private readonly IAccountDb _accountDb;
    private readonly ILogger<CreateAccountController> _logger;

    public CreateAccountController(ILogger<CreateAccountController> logger, IAccountDb accountDb)
    {
        _logger = logger;
        _accountDb = accountDb;
    }

    [HttpPost]
    public async Task<PkCreateAccountRes> Post(PkCreateAccountReq request)
    {
        var response = new PkCreateAccountRes();
        
        var errorCode = await _accountDb.CreateAccountAsync(request.Email, request.Password);
        if (errorCode != CSCommon.ErrorCode.None)
        {
            response.Result = errorCode;
            return response;
        }

        _logger.ZLogInformationWithPayload(new EventId(LogEventID.ApiCreateAccount), $"CreateAccount Email: {request.Email}");
        return response;
    }
}
