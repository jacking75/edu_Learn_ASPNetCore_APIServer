﻿using System;
using System.Threading.Tasks;
using APIServer.ModelReqRes;
using APIServer.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServerCommon;
using ServerCommon.Redis;
using ZLogger;
/*
namespace APIServer.Controllers;

[ApiController]
[Route("[controller]")]
public class EnterField : ControllerBase
{
    private readonly IGameDb _gameDb;
    private readonly ILogger _logger;
    private readonly MasterData _masterData;
    private readonly IRedisDb _redisDb;

    public EnterField(ILogger<EnterField> logger, IGameDb gameDb, IRedisDb redisDb, MasterData masterData)
    {
        _logger = logger;
        _gameDb = gameDb;
        _redisDb = redisDb;
        _masterData = masterData;
    }

    [HttpPost]
    public async Task<PkEnterFieldRes> Post(PkEnterFieldReq request)
    {
        var userInfo = (UserInfo)HttpContext.Items[nameof(UserInfo)];

        var response = new PkEnterFieldRes();
        
        var (errorCode, charInfo) = await _gameDb.GetEnterFieldInfo(request.NickName, request.WorldId);
        if (errorCode != ErrorCode.None)
        {
            response.Result = errorCode;
            return response;
        }

        if (charInfo.AccountId != request.AccountId)
        {
            _logger.ZLogError($"[EnterField] ErrorCode: {ErrorCode.InvalidCharacterInfo}");

            response.Result = ErrorCode.InvalidCharacterInfo;
            return response;
        }


        if (userInfo.Status == (Int32)CharacterStatus.EnterField)
        {
            _logger.ZLogError($"[EnterField] ErrorCode: {ErrorCode.DuplicatedLogin}");

            response.Result = ErrorCode.DuplicatedLogin;
            return response;
        }


        userInfo.CharacterId = charInfo.CharacterId;
        userInfo.NickName = request.NickName;
        userInfo.WorldId = (Int16)request.WorldId;
        userInfo.AuthTokenForField = Security.CreateAuthToken();
        userInfo.Status = (Int32)CharacterStatus.EnterField;        
        userInfo.FieldChannelNum = charInfo.ChannelNum;

        errorCode = await _redisDb.SetChangeUserInfo(request.AccountId, userInfo);
        if (errorCode != ErrorCode.None)
        {
            response.Result = errorCode;
            return response;
        }

        var worldInfo = _masterData.GetWorldInfo(request.WorldId);

        response.EnterFieldToken = userInfo.AuthTokenForField;
        response.WorldAddressIp = worldInfo.GateWayIp;
        response.WorldAddressPort = worldInfo.GateWayPort;

        return response;
    }
}
*/