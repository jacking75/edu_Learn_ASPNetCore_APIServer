using System;
using System.Threading.Tasks;
using APIServer.ModelReqRes;
using APIServer.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServerCommon;
using ServerCommon.FieldObjects;
using ServerCommon.Redis;
using ZLogger;

namespace APIServer.Controllers;

[ApiController]
[Route("[controller]")]
public class CreateCharacterController : ControllerBase
{
    private readonly IGameDb _gameDb;
    private readonly ILogger<CreateCharacterController> _logger;

    public CreateCharacterController(ILogger<CreateCharacterController> logger, IGameDb gameDb)
    {
        _logger = logger;
        _gameDb = gameDb;
    }

    [HttpPost]
    public async Task<PkCreateCharacterResp> Post(PkCreateCharacterReq request)
    {
        var response = new PkCreateCharacterResp();
                
        (var errorCode, var characterId) = await CreateCharacter(request.AccountId, request.WorldId, request.NickName);
        if (errorCode != CSCommon.ErrorCode.None)
        {
            response.Result = errorCode;
            return response;
        }

        _logger.ZLogInformationWithPayload(new EventId(LogEventID.ApiCreateCharacter),
            $"[CreateCharacter] AccountId : {request.AccountId}, WorldId : {request.WorldId}, Nickname : {request.NickName}, characterId : {characterId}");
        return response;
    }

    public async Task<(CSCommon.ErrorCode, Int64)> CreateCharacter(Int64 accountId, Int32 worldId, string nickName)
    {
        Int64 characterId = 0;
        CSCommon.ErrorCode errorCode = CSCommon.ErrorCode.None; 
        
        try
        {
            (errorCode, characterId) = await _gameDb.InsertCharacter(accountId, worldId, nickName);

            errorCode = await _gameDb.InsertCharacterItem(characterId, worldId);            
        }
        catch (Exception e)
        {
            DeleteCharacter(nickName, characterId, worldId);
            _logger.ZLogError(e, $"[CreateCharacterController] ErrorCode : {errorCode}, characterId : {characterId}");
        }

        return (CSCommon.ErrorCode.None, characterId);
    }

    public async void DeleteCharacter(string nickName, Int64 characterId, Int32 worldId)
    {   
        await _gameDb.DeleteCharacter(nickName);

        if (characterId != 0)
        {
            await _gameDb.DeleteCharacterItem(characterId);
        }
    }
}
