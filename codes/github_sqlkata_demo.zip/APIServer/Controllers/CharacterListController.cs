﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using APIServer.ModelReqRes;
using APIServer.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServerCommon.FieldObjects;
using ZLogger;

namespace APIServer.Controllers;

[ApiController]
[Route("[controller]")]
public class CharacterListController : Controller
{
    private readonly IGameDb _gameDb;
    private readonly ILogger<CharacterListController> _logger;

    public CharacterListController(ILogger<CharacterListController> logger, IGameDb gameDb)
    {
        _logger = logger;
        _gameDb = gameDb;
    }

    [HttpPost]
    public async Task<PkCharacterListRes> Post(PkCharacterListReq request)
    {
        var response = new PkCharacterListRes();

        var (errorCode, characters) = await _gameDb.GetCharacterList(request.AccountId);       
        if (errorCode != CSCommon.ErrorCode.None)
        {
            _logger.ZLogError($"[CharacterList] Error : {errorCode}");

            response.Result = errorCode;
            return response;
        }

        
        foreach (var character in characters)
        {
            var characterInfo = new CharacterInfo
            {
                Level = character.Level,
                NickName = character.NickName
            };

            response.CharacterInfoList.Add(characterInfo);
        }
                
        return response;
    }

    
}
