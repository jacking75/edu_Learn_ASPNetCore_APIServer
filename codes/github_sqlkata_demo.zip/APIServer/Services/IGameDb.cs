﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using APIServer.ModelReqRes;


namespace APIServer.Services;

public interface IGameDb
{
    public Task<Tuple<CSCommon.ErrorCode, Int64>> InsertCharacter(Int64 accountId, Int32 worldId, string nickName);

    public Task<CSCommon.ErrorCode> InsertCharacterItem(Int64 characterId, Int32 worldId);

    public Task<CSCommon.ErrorCode> DeleteCharacter(string nickName);

    public Task<CSCommon.ErrorCode> DeleteCharacterItem(Int64 characterId);

    public Task<Tuple<CSCommon.ErrorCode, IEnumerable<CharacterInfo>>> GetCharacterList(Int64 accountId);

    /*
    
    public Task<ErrorCode> ValidCharacterId(Int64 accountId, string nickName, Int32 worldId);

    

    public Task<Tuple<ErrorCode, List<CharacterLook>>> GetCharacterLookList(Int32 worldId,
        List<Int64> characterIdList);

    public Task<ErrorCode> DeleteCharacterItem(string nickName, Int32 worldId);

    public Task<Tuple<ErrorCode, IEnumerable<CharacterItem>>> GetCharacterItemsList(
        Int32 worldId, List<Int64> characterId, ItemStatus itemStatus);

    public Task<Tuple<ErrorCode, Int32>> CountCharacters(Int64 accountId, Int32 worldId);

    

    public Task<ErrorCode> DeleteCharacter(Int64 accountId, string nickName, Int32 worldId,
        ItemStatus itemStatus);

    public Task<(ErrorCode, ModelDB.EnterFieldCharacterInfo)> GetEnterFieldInfo(string nickName, Int32 worldId);*/


}