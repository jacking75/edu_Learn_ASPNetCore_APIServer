﻿using System;
using System.ComponentModel.DataAnnotations;
using CSCommon;

namespace APIServer.ModelReqRes;

public class PkCreateCharacterReq
{
    [Required] public Int64 AccountId { get; set; }

    [Required] public String AuthToken { get; set; }

    [Required]
    [Range(1, 2, ErrorMessage = "INVALID WORLD")]
    public Int32 WorldId { get; set; }

    public string NickName { get; set; }
}

public class PkCreateCharacterResp
{
    public ErrorCode Result { get; set; } = ErrorCode.None;
}

public class CreateCharacterInfo
{
    [Required]
    [MinLength(1, ErrorMessage = "NICKNAME CANNOT BE EMPTY")]
    [StringLength(8, ErrorMessage = "NICKNAME CANNOT EXCEED 18 CHARACTERS")]
    public String Nickname { get; set; }

    public Int32 Eye { get; set; }

    public Int32 HairStyle { get; set; }

    public Int32 Mustache { get; set; }

    public Int32 Cloak { get; set; }
    public Int32 Pants { get; set; }
    public Int32 Dress { get; set; }
    public Int32 Armor { get; set; }
    public Int32 Helmet { get; set; }
}