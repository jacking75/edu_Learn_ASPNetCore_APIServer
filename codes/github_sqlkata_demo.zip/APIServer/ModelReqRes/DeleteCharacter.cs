﻿using System;
using System.ComponentModel.DataAnnotations;
using CSCommon;

namespace APIServer.ModelReqRes;

public class PkDeleteCharacterReq
{
    [Required] public Int64 AccountId { get; set; }
    [Required] public string AuthToken { get; set; }
    [Required] public string NickName { get; set; }
    [Required] public Int32 WorldId { get; set; }
}

public class PkDeleteCharacterRes
{
    public CSCommon.ErrorCode Result { get; set; } = ErrorCode.None;
}