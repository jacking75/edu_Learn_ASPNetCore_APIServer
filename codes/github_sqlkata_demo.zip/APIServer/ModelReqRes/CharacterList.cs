﻿using System;
using System.Collections.Generic;
using CSCommon;

namespace APIServer.ModelReqRes;

[Serializable]
public class PkCharacterListReq
{
    public Int64 AccountId { get; set; }

    public String AuthToken { get; set; }
    public Int32 WorldId { get; set; }
}

[Serializable]
public class PkCharacterListRes
{
    public List<CharacterInfo> CharacterInfoList { get; set; } = new();
    public CSCommon.ErrorCode Result { get; set; } = ErrorCode.None;
}

public class CharacterInfo
{
    public Int32 Level { get; set; }
    public String NickName { get; set; }
}

public class CharacterLookInfo
{
    public Int64 CharacterId { get; set; }

    public Int32 Eye { get; set; }
    public Int32 HairStyle { get; set; }
    public Int32 Mustache { get; set; }
    public Int32 Cloak { get; set; }
    public Int32 Pants { get; set; }
    public Int32 Dress { get; set; }
    public Int32 Armor { get; set; }
    public Int32 Helmet { get; set; }
}