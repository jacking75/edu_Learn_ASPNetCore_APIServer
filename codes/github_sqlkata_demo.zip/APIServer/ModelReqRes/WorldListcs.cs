﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace APIServer.ModelReqRes;

public class PkWorldListReq
{
    [Required] public Int64 AccountId { get; set; }

    [Required] public String AuthToken { get; set; }
}

[Serializable]
public class PkWorldListRes
{
    public List<WorldInfo> WorldList { get; set; }
    public CSCommon.ErrorCode Result { get; set; } = CSCommon.ErrorCode.None;
}

public class WorldInfo
{
    public String Name { get; set; }
    public Int32 Id { get; set; }
}