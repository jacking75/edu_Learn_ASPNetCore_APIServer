﻿using System;
using System.ComponentModel.DataAnnotations;

namespace APIServer.ModelReqRes;

public class PkEnterFieldReq
{
    [Required] public Int64 AccountId { get; set; }

    [Required] public string AuthToken { get; set; }
    [Required] public Int32 WorldId { get; set; }
    [Required] public string NickName { get; set; }
}

public class PkEnterFieldRes
{
    [Required] public CSCommon.ErrorCode Result { get; set; }
    [Required] public string EnterFieldToken { get; set; }
    [Required] public string WorldAddressIp { get; set; }
    [Required] public string WorldAddressPort { get; set; }
}