﻿using System;
using System.ComponentModel.DataAnnotations;

namespace APIServer.ModelDB;


public class EnterFieldCharacterInfo
{
    public Int64 AccountId { get; set; }
    public Int64 CharacterId { get; set; }
    public Int16 ChannelNum { get; set; }
}