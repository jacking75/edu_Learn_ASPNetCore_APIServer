using System;
using System.Collections.Generic;
using APIServer.ModelDB;
using APIServer.ModelReqRes;
using APIServer.Services;
using ServerCommon;

namespace APIServer;

public class Query
{
    public class AccountDb
    {
        public static Tuple<String, Object> InsertCreateAccount(String email, String pw, String saltValue)
        {
            return new Tuple<String, Object>(
                "INSERT INTO Account(Email,SaltValue,HashedPassword) Values(@Email, @SaltValue, @HashedPassword); SELECT LAST_INSERT_ID();",
                new { Email = email, SaltValue = saltValue, HashedPassword = pw });
        }

        public static Tuple<String, Object> GetAccount(String email)
        {
            return new Tuple<String, Object>(
                "SELECT AccountId,HashedPassword,SaltValue FROM Account WHERE Email = @Email",
                new { Email = email });
        }
    }

    public class GameDb
    {
        /*public static Tuple<String, Object> CreateCharacterLookArmor(Int64 characterId, CreateCharacterInfo character)
        {
            return new Tuple<String, Object>(
                "INSERT INTO CharacterItem(CharacterId, Code)   " +
                "VALUES(@CharacterId, @Code); SELECT LAST_INSERT_ID();",
                new
                {
                    CharacterId = characterId,
                    Code = character.Armor
                });
        }

        public static Tuple<String, Object> CreateCharacterLookHelmet(Int64 characterId, CreateCharacterInfo character)
        {
            return new Tuple<String, Object>(
                "INSERT INTO CharacterItem(CharacterId, Code)   " +
                "VALUES(@CharacterId, @Code); SELECT LAST_INSERT_ID();",
                new
                {
                    CharacterId = characterId,
                    Code = character.Armor
                });
        }

        public static Tuple<String, Object> CreateCharacterWeapon(Int32 weaponNumber, Int64 characterId)
        {
            return new Tuple<String, Object>(
                "INSERT INTO CharacterItem(CharacterId, Code)   " +
                "VALUES(@CharacterId, @WeaponNumber); SELECT LAST_INSERT_ID();",
                new
                {
                    CharacterId = characterId,
                    WeaponNumber = weaponNumber
                });
        }


        public static Tuple<String, Object> CreateCharacterArmor(Int32 armorNumber, Int64 characterId)
        {
            return new Tuple<String, Object>(
                "INSERT INTO CharacterItem(CharacterId, Code)   " +
                "VALUES(@CharacterId, @ArmorNumber); SELECT LAST_INSERT_ID();",
                new
                {
                    CharacterId = characterId,
                    ArmorNumber = armorNumber
                });
        }

        public static Tuple<String, Object> CreateCharacterHelmet(Int32 helmetNumber, Int64 characterId)
        {
            return new Tuple<String, Object>(
                "INSERT INTO CharacterItem(CharacterId, Code)   " +
                "VALUES(@CharacterId, @HelmetNumber); SELECT LAST_INSERT_ID();",
                new
                {
                    CharacterId = characterId,
                    HelmetNumber = helmetNumber
                });
        }

        public static Tuple<String, Object> CreateCharacterItem(Int64 characterId, CreateCharacterInfo characterInfo)
        {
            return new Tuple<String, Object>(
                @"INSERT INTO CharacterItem(CharacterId, Code) 
                  VALUES  (@CharacterId, @Dress), (@CharacterId, @Pants), (@CharacterId, @HairStyle), (@CharacterId, @Mustache), (@CharacterId, @Cloak), (@CharacterId, @Helmet), (@CharacterId, @Armor);",
                new
                {
                    CharacterId = characterId,
                    characterInfo.Dress,
                    characterInfo.Pants,
                    characterInfo.HairStyle,
                    characterInfo.Mustache,
                    characterInfo.Cloak,
                    characterInfo.Helmet,
                    characterInfo.Armor
                });
        }

        public static Tuple<String, Object> CreateCharacterLook(Int64 characterId, CreateCharacterInfo characterInfo)
        {
            return new Tuple<String, Object>(
                "INSERT INTO CharacterLook(CharacterId, Dress, Pants, Eye, HairStyle, Mustache, Cloak, Helmet, Armor)   " +
                "VALUES(@CharacterId, @Dress, @Pants, @Eye, @HairStyle, @Mustache, @Cloak, @Helmet, @Armor); SELECT LAST_INSERT_ID();",
                new
                {
                    CharacterId = characterId,
                    characterInfo.Dress,
                    characterInfo.Pants,
                    characterInfo.Eye,
                    characterInfo.HairStyle,
                    characterInfo.Mustache,
                    characterInfo.Cloak,
                    characterInfo.Helmet,
                    characterInfo.Armor
                });
        }

        //캐릭터 커스텀 옷 삭제 
        public static Tuple<string, Object> DeleteCreateCharacterDress(string nickName)
        {
            return new Tuple<String, Object>(
                "DELETE FROM `CharacterLook` WHERE NickName = @NickName",
                new { NickName = nickName });
        }

        //캐릭터 삭제 
        public static Tuple<string, Object> DeleteCreateCharacter(string nickName)
        {
            return new Tuple<string, Object>(
                "DELETE FROM `Character` WHERE NickName = @NickName",
                new { NickName = nickName });
        }

        //캐릭터 아이템 삭제 
        public static Tuple<String, Object> DeleteCharacterItem(string nickName)
        {
            return new Tuple<string, Object>(
                "DELETE FROM `CharacterItem` WHERE CharacterId = @CharacterId",
                new { NickName = nickName });
        }

        public static Tuple<string, Object> UpdateCharacterItem(string nickName, ItemStatus itemStatus)
        {
            return new Tuple<string, Object>(
                "UPDATE `CharacterItem` SET Status = @ItemStatus WHERE NickName = @NickName;",
                new { ItemStatus = itemStatus, NickName = nickName });
        }

        public static Tuple<string, Object> UpdateCharacterDress(string nickName)
        {
            return new Tuple<String, Object>(
                "UPDATE `CharacterLook` SET IsDelete = @CharacterStatus WHERE NickName = @NickName;",
                new { CharacterStatus = 1, NickName = nickName });
        }

        public static Tuple<string, Object> GetAccountId(string nickName)
        {
            return new Tuple<string, Object>(
                "SELECT AccountId from `Character`  WHERE nickName = @nickName ",
                new { NickName = nickName }
            );
        }

        public static Tuple<String, Object> GetCharacterItemCodes(List<Int64> characterId)
        {
            return new Tuple<String, Object>(
                "SELECT Code, CharacterId from `CharacterItem`  WHERE CharacterId IN @ids ",
                new { ids = characterId }
            );
        }

        public static Tuple<string, Object> UpdateCharacter(string nickName)
        {
            return new Tuple<String, Object>(
                "UPDATE `Character` SET IsDelete = @CharacterStatus  WHERE NickName = @NickName;",
                new { CharacterStatus = 1, NickName = nickName });
        }

        public static Tuple<string, Object> CreateCharacter(String nickname, Int64 accountId,
            MasterCharacterInfo masterCharacterInfo)
        {
            return new Tuple<String, Object>(
                @"INSERT INTO `Character`(AccountId, Nickname, Exp, Level, Hp, Mp, LocationX, LocationY, Gold) 
                Values(@AccountId, @Nickname, @Exp, @Level, @Hp, @Mp, @LocationX, @LocationY, @Gold); 
                SELECT LAST_INSERT_ID();",
                new
                {
                    AccountId = accountId,
                    Nickname = nickname,
                    masterCharacterInfo.Exp,
                    masterCharacterInfo.Level,
                    masterCharacterInfo.Hp,
                    masterCharacterInfo.Mp,
                    masterCharacterInfo.LocationX,
                    masterCharacterInfo.LocationY,
                    masterCharacterInfo.Gold
                });
        }


        public static Tuple<String, Account> GetCharacterInfo(Int64 accountId)
        {
            return new Tuple<String, Account>(
                "SELECT `Level`, Nickname,  CharacterId, AccountId FROM `Character`  WHERE AccountId = @AccountId AND NOT IsStatus = 1",
                new Account { AccountId = accountId }
            );
        }

        public static Tuple<String, Object> GetCharacterLookInfo(List<Int64> characterId)
        {
            return new Tuple<String, Object>(
                "SELECT CharacterId, Eye, HairStyle, Mustache, Cloak, Pants, Dress, Helmet, Armor FROM `CharacterLook`  WHERE CharacterId  IN @ids AND IsDelete = FALSE",
                new { ids = characterId }
            );
        }

        public static Tuple<String, Object> GetCharacterItemCodeInfo(List<Int64> characterId, ItemStatus itemStatus)
        {
            return new Tuple<String, Object>(
                "SELECT CharacterId, Code, CharacterItemId , Status  FROM `CharacterItem` WHERE CharacterId IN @ids AND Status = @ItemStatus",
                new { ids = characterId, ItemStatus = itemStatus }
            );
        }

        public static Tuple<String, Object> CountCharacters(Int64 accountId)
        {
            return new Tuple<String, Object>(
                "SELECT COUNT(*) FROM `Character` WHERE AccountId  = @AccountId ",
                new { AccountId = accountId }
            );
        }

        public static Tuple<String, Object> GetCharacterStatus(Int64 accountId, Int64 characterId)
        {
            return new Tuple<String, Object>(
                "SELECT IsStatus FROM `Character` WHERE CharacterId = @CharacterId",
                new { CharacterId = characterId }
            );
        }

        public static Tuple<String, Object> GetCharacter(string nickName)
        {
            return new Tuple<String, Object>(
                "SELECT AccountId, CharacterId, ChannelNum FROM `Character` WHERE Nickname = @Nickname AND IsDelete = 0",
                new { Nickname = nickName }
            );
        }*/
    }
    
}